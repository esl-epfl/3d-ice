#!/bin/bash

wget https://zenodo.org/record/3345878/files/release.tar.gz
tar xf release.tar.gz
mv release/heatsink          traces-nofan
mv release/heatsink_with_fan traces-fan
rm -rf release
# These two files exceed the fitting power range
rm traces-fan/sixteen.csv
rm traces-nofan/sixteen.csv
