
To run the validation scripts, do:

Move all the validation files in the validation-scripts.tar.gz archive in the HS483 directory

./download.sh
./toplevel-batch-nofan.sh
./toplevel-batch-fan.sh
