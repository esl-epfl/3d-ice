#!/bin/bash

dir=$1;

if [[ -z $dir ]]; then
    dir="out";
fi

reformat() {
    perl -ne 'next unless(/(\d+\.\d+)\s+(\d+\.\d+)/); print "$1 $2\n";' < "$2/$1.txt" > "$2/_"
    rm "$2/$1.txt"
    mv "$2/_" "$2/$1.txt"
}

reformat A1 $dir
reformat A2 $dir
reformat A3 $dir
reformat A4 $dir
reformat B1 $dir
reformat B2 $dir
reformat B3 $dir
reformat B4 $dir
reformat C1 $dir
reformat C2 $dir
reformat C3 $dir
reformat C4 $dir
reformat D1 $dir
reformat D2 $dir
reformat D3 $dir
reformat D4 $dir
